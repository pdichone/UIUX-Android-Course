package bawpapp.buildappswithpaulo.com.bawp.controller;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import bawpapp.buildappswithpaulo.com.bawp.R;

public class CreateAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_account);
    }
}
